﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController : MonoBehaviour {

	Vector2 goal;
	GameObject goalObject;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void SetGoal(Vector2 g) {
		goal = g;
	}

	public bool CheckGoal(Vector2 loc){
		return loc.x == goal.x;
	}

	public void InstantiateObjects(){
		goalObject = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Goal"), new Vector2 (goal.x*2, goal.y*2), Quaternion.identity);
	}

}
