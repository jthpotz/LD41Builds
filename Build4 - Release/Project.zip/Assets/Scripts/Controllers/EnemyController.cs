﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using EnemyTypes = Constants.EnemyTypes;

public class EnemyController : MonoBehaviour {

	List<Enemy> enemies = null;
	List<GameObject> enemyObjects = new List<GameObject> ();

	bool loaded = false;

	EventController ec;

	// Use this for initialization
	void Start () {
		ec = GameObject.FindGameObjectWithTag ("EventController").GetComponent<EventController> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(enemies == null){
			return;
		}
		if(!loaded){
			GameObject go;
			foreach (Enemy e in enemies) {
//				Debug.Log (e);
				switch (e.Type) {
					case EnemyTypes.Slime:
						go = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Slime"), new Vector2 (e.Position.x * 2, e.Position.y * 2 - 0.0625f), Quaternion.identity);
						enemyObjects.Add (go);
						go.GetComponent<EnemyManager> ().InitializeEnemy (e);
						break;
					case EnemyTypes.Bouncy:
						go = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Bouncy"), new Vector2 (e.Position.x * 2, e.Position.y * 2 - 0.0625f), Quaternion.identity);
						enemyObjects.Add (go);
						go.GetComponent<EnemyManager> ().InitializeEnemy (e);
						break;
				}
				loaded = true;
			}
		}
	}

	public void LoadEnemies (List<Enemy> e){
		enemies = e;
	}

	public void ActivateEnemies (){
		EnemyManager em;
		foreach (GameObject go in enemyObjects){
			em = go.GetComponent<EnemyManager> ();
			if (em.CheckForActive ()){
				em.DoAction ();
			}

		}
	}

	public void RemoveEnemy (GameObject go) {
		enemyObjects.Remove (go);
		enemies.Remove (go.GetComponent<EnemyManager> ().Enemy);
	}

	public bool CollideWithEnemy (Vector2 loc) {
		foreach (Enemy e in enemies){
			if(e.Position == loc){
				return true;
			}
		}
		return false;
	}

	public EnemyManager EnemyAt (Vector2 loc){
		EnemyManager em;
		foreach (GameObject go in enemyObjects){
			em = go.GetComponent<EnemyManager> ();
			if(em.Enemy.Position == loc){
				return em;
			}
		}
		return null;
	}

}
