﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	Player player;
	GameObject playerObject;
	PlayerManager pm;

	EventController ec;
	MapController mc;
	EnemyController emc;
	ObjectController oc;
	SceneController sc;

	public Player Player {
		get {
			return player;
		}
	}

	public EventController EC {
		get {
			return ec;
		}
	}

	public PlayerManager PM {
		get {
			return pm;
		}
	}

	public MapController MC {
		get {
			return mc;
		}
	}

	public EnemyController EMC {
		get {
			return emc;
		}
	}

	public ObjectController OC {
		get {
			return oc;
		}
	}

	public SceneController SC {
		get {
			return sc;
		}
	}

	// Use this for initialization
	void Start () {
		player = new Player ();
		playerObject = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Player"), new Vector2 (player.Position.x * 2, player.Position.y * 2 - 0.0625f), Quaternion.identity);
		GameObject.FindGameObjectWithTag ("CardController").GetComponent<CardController> ().InstantiatePlayerObject (playerObject);
		ec = GameObject.FindGameObjectWithTag ("EventController").GetComponent <EventController> ();
		mc = GameObject.FindGameObjectWithTag ("MapController").GetComponent <MapController> ();
		emc = GameObject.FindGameObjectWithTag ("EnemyController").GetComponent<EnemyController> ();
		oc = GameObject.FindGameObjectWithTag ("ObjectController").GetComponent<ObjectController> ();
		sc = GameObject.FindGameObjectWithTag ("SceneController").GetComponent<SceneController> ();
		pm = playerObject.GetComponent<PlayerManager> ();

//		GameObject temp = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Gridlines"), new Vector2 (playerObject.transform.position.x+1, playerObject.transform.position.y+1), Quaternion.identity);
//		ec.InitializeGridlines (temp);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
