﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneController : MonoBehaviour {

	int level = 0;

	AudioSource mainAudioSource;

	public int Level {
		get {
			return level;
		}
	}

	public AudioSource MainAudioSource {
		get {
			return mainAudioSource;
		}
	}

	// Use this for initialization
	void Start () {
		Object.DontDestroyOnLoad (gameObject);
		mainAudioSource = GetComponent<AudioSource> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey (KeyCode.Escape)){
			Application.Quit ();
		}
//		Debug.Log (mainAudioSource); 
	}

	public void StartButton(){
//		mainAudioSource = GetComponent<AudioSource> ();
//		MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/NewGame");
//		MainAudioSource.Play ();
		SceneManager.LoadScene ("Level0");
	}

	public void EndGame (){
		if(level > 0){
			level = 1;
		}
		else{
			level = 0;
		}
//		mainAudioSource = GetComponent<AudioSource> ();
//		MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/GameOver");
//		MainAudioSource.Play ();
		SceneManager.LoadScene ("GameOver");
	}

	public void MainMenu(){
		SceneManager.LoadScene ("MainMenu");
	}

	public void NextLevelScreen(){
		level++;
		SceneManager.LoadScene ("NextLevel");
	}

	public void NextLevel(){
//		mainAudioSource = GetComponent<AudioSource> ();
//		MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/NewGame");
//		MainAudioSource.Play ();
		SceneManager.LoadScene ("Level");
	}

}
