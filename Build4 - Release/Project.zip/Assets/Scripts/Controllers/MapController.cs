﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TerrainTypes = Constants.TerrainTypes;

public class MapController : MonoBehaviour {

	Map map;
	GameObject[,] mapObjects;

	public int level = 0;

	public Map Map {
		get {
			return map;
		}
	}

	// Use this for initialization
	void Start () {
		level = GameObject.FindGameObjectWithTag ("SceneController").GetComponent<SceneController> ().Level;
		map = new Map (MapLoader.LoadMap (level));
		mapObjects = new GameObject[map.EntireMap.GetUpperBound (0), map.EntireMap.GetUpperBound (1)];
		for (int x = 0; x < map.EntireMap.GetUpperBound (0); x++){
			for(int y = 0; y < map.EntireMap.GetUpperBound (1); y++){
//				Debug.Log ("Map object: " + map);
//				Debug.Log ("Map array: " + map.EntireMap);
//				Debug.Log ("Tile object: " + map.EntireMap [0, 0]);
//				Debug.Log ("Tile terrain: " + map.EntireMap [0, 0].TerrainType);
				switch (map.EntireMap[x,y].TerrainType){
					case TerrainTypes.Ground:
						mapObjects [x, y] = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/GroundTile"), new Vector2 (x*2, y*2), Quaternion.identity);
						break;
					case TerrainTypes.Sky:
						mapObjects [x, y] = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/SkyTile"), new Vector2 (x*2, y*2), Quaternion.identity);
						break;
				}
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public bool InsideVisibleArea (Vector2 pos){
		return (pos.x < map.TopRightVisible.x && pos.x > map.BottomLeftVisible.x); //&& (pos.y < map.TopRightVisible.y && pos.y > map.BottomLeftVisible.y)
	}

	public bool Passable(Vector2 loc){
		return map.Passable (loc);
	}

}
