﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class EventController : MonoBehaviour {

	Queue<Action> actions = new Queue<Action>();

	bool doTurn = false;

	bool animating = false;
	Action animatingAction;

	float amount = 0;

	MapController mc;
	PlayerController pc;
	EnemyController ec;

	bool player = true;

//	GameObject gridlines;


	public bool Animating {
		get {
			return animating;
		}
		set {
			animating = value;
		}
	}

	public bool DoTurn {
		get {
			return doTurn;
		}
	}

	public float Amount {
		get {
			return amount;
		}
		set {
			amount = value;
		}
	}

	// Use this for initialization
	void Start () {
		mc = GameObject.FindGameObjectWithTag ("MapController").GetComponent<MapController> ();
		pc = GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ();
		ec = GameObject.FindGameObjectWithTag ("EnemyController").GetComponent<EnemyController> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(animating){
			animatingAction ();
//			Debug.Log ("Animating Here!");
			return;
		}
		if(actions.Count == 0){
			doTurn = false;
		}
		if(doTurn && !animating){
			actions.Dequeue () ();
			if(actions.Count == 0){
				if(player){
					player = false;
					ec.ActivateEnemies ();
					doTurn = true;
					return;
				}
				else {
					player = true;
				}
			}

		}
	}

	public void ExecuteTurn(){
		doTurn = true;

	}

	public void QueueAction(Action a){
		actions.Enqueue (a);
	}

	public void AddAnimatingAction(Action a){
		animatingAction = a;
		animating = true;
	}

	public void ClearAnimation (){
		animatingAction = null;
		amount = 0;
		animating = false;
//		Debug.Log ("Move Grid"); 
//		gridlines.transform.position = new Vector2 (pc.PM.transform.position.x + 1, pc.PM.transform.position.y + 1);
		if(!doTurn){
			
		}
	}

	public void CheckFalling (bool player, EnemyManager em = null){
		if (player) {
			if (mc.Passable (new Vector2 (pc.Player.Position.x, pc.Player.Position.y - 1))) {
				if (pc.Player.Gliding && pc.Player.GlideRemaining > 0) {
					pc.Player.UseGlide ();
				} else {
					pc.Player.HaltGlide ();
					if(ec.CollideWithEnemy (new Vector2 (pc.Player.Position.x, pc.Player.Position.y - 1))){
						ec.EnemyAt (new Vector2 (pc.Player.Position.x, pc.Player.Position.y - 1)).Die ();
					}
					AddAnimatingAction (() => {
						pc.PM.transform.Translate (new Vector2 (0, -Time.deltaTime * Constants.speed));
						amount += Time.deltaTime * Constants.speed;
						if (amount >= 2) {
							pc.PM.transform.position = new Vector2 (Mathf.Round (pc.PM.transform.position.x), Mathf.Round (pc.PM.transform.position.y) - 0.0625f);
							ClearAnimation ();
							if (pc.Player.Position.y == 1) {
								GameOver ();
							}
							CheckFalling (true);
						}
					});
					pc.Player.MoveDown ();
					pc.MC.Map.ShiftVisibleDown ();
				}
			} else {
				pc.Player.HaltGlide ();
			}
		}
		else {
			if (mc.Passable (new Vector2 (em.Enemy.Position.x, em.Enemy.Position.y - 1))) {
				if(new Vector2 (em.Enemy.Position.x, em.Enemy.Position.y - 1) == pc.Player.Position){
					GameOver ();
				}
				AddAnimatingAction (() => {
					em.transform.Translate (new Vector2 (0, -Time.deltaTime * Constants.speed));
					amount += Time.deltaTime * Constants.speed;
					if (amount >= 2) {
						em.transform.position = new Vector2 (Mathf.Round (em.transform.position.x), Mathf.Round (em.transform.position.y) - 0.0625f);
						ClearAnimation ();
						if(em.transform.position.y > 0){
							CheckFalling (false, em);	
						}
						else{
							ec.RemoveEnemy (em.gameObject);
							//GameObject.Destroy (em.gameObject);
							em.Die ();
						}
					}
				});
				em.Enemy.MoveDown ();
			}
		}
	}

	public void GameOver (){
		GameObject.FindGameObjectWithTag ("SceneController").GetComponent<SceneController> ().EndGame ();
//		Debug.LogError ("Game Over -- Still needs implementation!");
	}

//	public void InitializeGridlines(GameObject g){
//		gridlines = g;
//	}

}
