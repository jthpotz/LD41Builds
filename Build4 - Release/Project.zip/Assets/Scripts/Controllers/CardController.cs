﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;

using CardNames = Constants.CardNames;

public class CardController : MonoBehaviour {

	Deck currentDeck;
	Hand currentHand;

	GameObject playerObject;
	GameObject handObject;

	List<GameObject> currentCards = new List<GameObject> ();

	bool shifting = false;

	float dist = 0;

	EventController ec;

	public bool Shifting {
		get {
			return shifting;
		}
	}

	// Use this for initialization
	void Awake () {
		currentDeck = new Deck ();

		currentDeck.AddCardToDeck (new Card.Jump ());
		currentDeck.AddCardToDeck (new Card.Jump ());
		//currentDeck.AddCardToDeck (new Card.Jump ());
		currentDeck.AddCardToDeck (new Card.Dash ());
		currentDeck.AddCardToDeck (new Card.Dash ());
		currentDeck.AddCardToDeck (new Card.Halt ());
		currentDeck.AddCardToDeck (new Card.Strike ());
		currentDeck.AddCardToDeck (new Card.Strike ());

		currentHand = new Hand (currentDeck);
//		Debug.Log (currentHand);

		ec = GameObject.FindGameObjectWithTag ("EventController").GetComponent<EventController> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(playerObject == null){
			return;
		}
		if (shifting) {
			for (int i = 0; i < currentCards.Count; i++){
				if (Mathf.Floor(currentCards [i].transform.localPosition.x) != 10 - (i * 4)) {
					//currentCards [i].transform.localPosition = new Vector2 (8 - (i * 4), currentCards [i].transform.localPosition.y);
					currentCards [i].transform.Translate (new Vector2 (Time.deltaTime*Constants.speed, 0));
				}
			}
			dist += Time.deltaTime*Constants.speed;
			if (dist >= 4f){
				dist = 0;
				shifting = false;
				DisplayCard (currentHand.CurrentHand.Last ().Name, currentHand.CurrentHand.Length-1);
				foreach(GameObject go in currentCards){
					go.transform.position = new Vector2 (Mathf.Round (go.transform.position.x), Mathf.Round (go.transform.position.y));
				}
			}
		}
	}

	public void InstantiatePlayerObject (GameObject p){
		playerObject = p;
		LoadHand ();
	}

	private void LoadHand (){
		List<Transform> list = playerObject.GetComponentsInChildren<Transform> ().ToList ();
		foreach (Transform t in list) {
			if (t.tag == "Hand") {
				handObject = t.gameObject;
			}
		}
		DisplayCards ();
	}

	private void DisplayCards (){
		//GameObject tempCard;
//		Debug.Log(currentHand);
		for (int i = 0; i < currentHand.CurrentHand.Length; i++) {
			DisplayCard (currentHand.CurrentHand[i].Name, i);
		}

	}

	private void DisplayCard (CardNames n, int i){
		GameObject tempCard;
		switch (n) {
			case CardNames.Right:
				tempCard = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Cards/Right"), new Vector2 (8, 4), Quaternion.identity);
				tempCard.transform.SetParent (handObject.transform);
				tempCard.transform.localPosition = new Vector2 (10, -4);
				currentCards.Add (tempCard);
				break;
			case CardNames.Jump:
				tempCard = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Cards/Jump"), new Vector2 (8 - (i * 4), 4), Quaternion.identity);
				tempCard.transform.SetParent (handObject.transform);
				tempCard.transform.localPosition = new Vector2 (10 - (i * 4), -4);
				currentCards.Add (tempCard);
				break;
			case CardNames.Dash:
				tempCard = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Cards/Dash"), new Vector2 (8-(i*4), 4), Quaternion.identity);
				tempCard.transform.SetParent (handObject.transform);
				tempCard.transform.localPosition = new Vector2 (10 - (i * 4), -4);
				currentCards.Add (tempCard);
				break;
			case CardNames.Halt:
				tempCard = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Cards/Halt"), new Vector2 (8-(i*4), 4), Quaternion.identity);
				tempCard.transform.SetParent (handObject.transform);
				tempCard.transform.localPosition = new Vector2 (10 - (i * 4), -4);
				currentCards.Add (tempCard);
				break;
			case CardNames.Strike:
				tempCard = GameObject.Instantiate (Resources.Load<GameObject> ("Prefabs/Cards/Strike"), new Vector2 (8-(i*4), 4), Quaternion.identity);
				tempCard.transform.SetParent (handObject.transform);
				tempCard.transform.localPosition = new Vector2 (10 - (i * 4), -4);
				currentCards.Add (tempCard);
				break;
		}
	}

	public void UseCard(GameObject cardObject){
		int index = currentCards.IndexOf (cardObject);
//		if(currentHand.CurrentHand[index].Type == Constants.CardTypes.Movement  && currentHand.CurrentHand[index].Name != Constants.CardNames.Halt){
//			ec.QueueAction (() => currentHand.CurrentHand [index].Effect (GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ()));
//		}
//		if(index != 0){
//			currentCards.RemoveAt (index);
//			ShiftCards ();
//			ec.QueueAction (() => currentHand.CurrentHand [0].Effect (GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ()));
//		}
//		if(currentHand.CurrentHand[index].Type == Constants.CardTypes.Attack  && currentHand.CurrentHand[index].Name != Constants.CardNames.Halt){
//			ec.QueueAction (() => currentHand.CurrentHand [index].Effect (GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ()));
//		}
//		Debug.Log ("UseCard: " + currentHand.CurrentHand[index].Name);
		if(index == 0){
			ec.QueueAction (() => currentHand.CurrentHand [0].Effect (GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ()));
		}
		else{
			Action<PlayerController> a = currentHand.CurrentHand [index].Effect;
//			switch(currentHand.CurrentHand[index].Type){
//				case Constants.CardTypes.Attack:
//					Debug.Log ("Alpha: " + a.ToString () + " " + a.Method );
//					ec.QueueAction (() => currentHand.CurrentHand [0].Effect (GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ()));
//					ec.QueueAction (() => a((GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ())));
//					break;
//				case Constants.CardTypes.Movement:
					ec.QueueAction (() => a((GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ())));
					if (currentHand.CurrentHand[index].Name != Constants.CardNames.Halt){
						ec.QueueAction (() => currentHand.CurrentHand [0].Effect (GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ()));
					}
//					break;
//			}
			currentHand.UseCardAt (index, currentDeck);
			currentCards.RemoveAt (index);

			ShiftCards ();
		}

		ec.ExecuteTurn ();
	}


	private void ShiftCards(){
		shifting = true;
	}
}
