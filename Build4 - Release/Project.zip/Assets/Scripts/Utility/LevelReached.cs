﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelReached : MonoBehaviour {

	// Use this for initialization
	void Start () {
		GameObject.FindGameObjectWithTag ("Text").GetComponent<Text> ().text += GameObject.FindGameObjectWithTag ("SceneController").GetComponent<SceneController> ().Level;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
