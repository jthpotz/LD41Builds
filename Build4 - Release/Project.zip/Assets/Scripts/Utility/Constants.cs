﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Constants  {

	public const int handSize = 4;

	public const int startingMapHeight = 1;
	public const float startingPlayerHeight = startingMapHeight + 2;

	public const int playerGlideAmount = 1;

	public const int speed = 4;

	public static int moveHash = Animator.StringToHash ("Move");
	public static int jumpHash = Animator.StringToHash ("Jump");
	public static int dashHash = Animator.StringToHash ("Dash");
	public static int idleHash = Animator.StringToHash ("Idle");
	public static int deadHash = Animator.StringToHash ("Dead");
	public static int hackHash = Animator.StringToHash ("Hack");


//	public const int 


	public enum TerrainTypes {
		Ground,
		Sky,
		UnderGround
	}

	public enum CardTypes {
		Movement,
		Attack
	}

	public enum EnemyTypes {
		Slime,
		Bouncy
	}

	public enum CardNames {
		Right,
		Jump,
		Dash,
		Halt,
		Strike
	}

	public static Color ground = new Color (0x79, 0x33, 0x00);
	public static Color sky = new Color (0xFF, 0xFF, 0xFF);
	public static Color underground = new Color (0x00, 0x00, 0x00);
	public static Color slime = new Color (0x4C, 0xFF, 0x00);
	public static Color goal = new Color (0xFF, 0xD8, 0x00);
	public static Color treasure = new Color (0xFF, 0x94, 0x00);
	public static Color bouncy = new Color (0xFF, 0x00, 0x08);

}
