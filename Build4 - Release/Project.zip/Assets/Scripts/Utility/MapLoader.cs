﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

using TerrainTypes = Constants.TerrainTypes;
using EnemyTypes = Constants.EnemyTypes;

public static class MapLoader {

	public static TileSpace[,] LoadMap (int level){
		List<Color> colors = new List<Color>();
		colors.Add (Constants.ground);
		colors.Add (Constants.sky);
		colors.Add (Constants.underground);
		colors.Add (Constants.slime);
		colors.Add (Constants.goal);
		colors.Add (Constants.treasure);
		colors.Add (Constants.bouncy);
//		Debug.LogWarning ("MapLoader not fully implemented!");
		Texture2D image;
		TileSpace[,] map;
		List<Enemy> enemies = new List<Enemy> ();
		if(level == 0){
			string test = "Levels/Level0";
			image = Resources.Load (test) as Texture2D;
			map = new TileSpace[image.width, image.height];
			Color c;
			for (int x = 0; x < image.width; x++){
				for (int y = 0; y < image.height; y++) {
					c = image.GetPixel (x, y);
					c.r *= 255;
					c.g *= 255;
					c.b *= 255;
					switch(IndexOfColor (colors, c)){
						case 0:
							map [x, y] = new TileSpace (TerrainTypes.Ground);
							break;
						case 1:
							map [x, y] = new TileSpace (TerrainTypes.Sky);
							break;
						case 2:
							map [x, y] = new TileSpace (TerrainTypes.Ground); //Switch to underground eventually
							break;
						case 3:
							map [x, y] = new TileSpace (TerrainTypes.Sky);
							enemies.Add (new Enemy (EnemyTypes.Slime, new Vector2 (x, y)));
							break;
						case 4:
							map [x, y] = new TileSpace (TerrainTypes.Sky); //This is not proper! need to do goal stuff
							GameObject.FindGameObjectWithTag ("ObjectController").GetComponent<ObjectController> ().SetGoal (new Vector2(x, y));
							break;
						case 5:
							map [x, y] = new TileSpace (TerrainTypes.Sky); //This is not proper! need to do treasure stuff
							break;
						case 6:
							map [x, y] = new TileSpace (TerrainTypes.Sky);
							enemies.Add (new Enemy (EnemyTypes.Bouncy, new Vector2 (x, y)));
							break;
					}


				}
			}
		}
		else {
			Color c;
			List<Texture2D> images = new List<Texture2D> ();
			int numSections = 3 + level + 2 * Random.Range (1, level);
			int width = 8*(numSections+1);
			images.Add (Resources.Load<Texture2D> ("Levels/SectionStart"));
			for(int i = 0; i < numSections-1; i++){
				images.Add (Resources.Load<Texture2D> ("Levels/Section" + Random.Range (0, 10)));
			}
			images.Add (Resources.Load<Texture2D> ("Levels/SectionGoal")); 
			map = new TileSpace[width, 8];
			for(int i = 0; i < images.Count; i++){
				for (int x = 0; x < images[i].width; x++){
					for (int y = 0; y < images[i].height; y++) {
						c = images[i].GetPixel (x, y);
						c.r *= 255;
						c.g *= 255;
						c.b *= 255;
						switch(IndexOfColor (colors, c)){
							case 0:
								map [x+8*i, y] = new TileSpace (TerrainTypes.Ground);
								break;
							case 1:
								map [x+8*i, y] = new TileSpace (TerrainTypes.Sky);
								break;
							case 2:
								map [x+8*i, y] = new TileSpace (TerrainTypes.Ground); //Switch to underground eventually
								break;
							case 3:
								map [x+8*i, y] = new TileSpace (TerrainTypes.Sky);
								enemies.Add (new Enemy (EnemyTypes.Slime, new Vector2 (x+8*i, y)));
								break;
							case 4:
								map [x+8*i, y] = new TileSpace (TerrainTypes.Sky); //This is not proper! need to do goal stuff
								GameObject.FindGameObjectWithTag ("ObjectController").GetComponent<ObjectController> ().SetGoal (new Vector2(x+8*i, y));
								break;
							case 5:
								map [x+8*i, y] = new TileSpace (TerrainTypes.Sky); //This is not proper! need to do treasure stuff
								break;
							case 6:
								map [x+8*i, y] = new TileSpace (TerrainTypes.Sky);
								enemies.Add (new Enemy (EnemyTypes.Bouncy, new Vector2 (x+8*i, y)));
								break;
						}


					}
				}
			}
		}
		GameObject.FindGameObjectWithTag ("ObjectController").GetComponent<ObjectController> ().InstantiateObjects ();
		GameObject.FindGameObjectWithTag ("EnemyController").GetComponent<EnemyController> ().LoadEnemies (enemies);
		return map;
	}


	private static bool CompareColors (Color c1, Color c2){
//		return Mathf.Abs(c1.r - Mathf.Floor(c2.r*255)) < 5 && Mathf.Abs(c1.g - Mathf.Floor (c2.g*255)) < 5 && Mathf.Abs (c1.b - Mathf.Floor (c2.b*255)) < 5;
		return Mathf.Approximately(c1.r, c2.r) && Mathf.Approximately(c1.g, c2.g)&& Mathf.Approximately(c1.b, c2.b);
	}

	private static int IndexOfColor(List<Color> colors, Color target){
		var colorDiffs = colors.Select (n => ColorDiff (n, target)).Min (n => n);
		return colors.FindIndex (n => ColorDiff (n, target) == colorDiffs);
	}

	private static int ColorDiff(Color c1, Color c2) {
		return (int)Mathf.Sqrt ((c1.r - c2.r) * (c1.r - c2.r) +
		(c1.g - c2.g) * (c1.g - c2.g) +
		(c1.b - c2.b) * (c1.b - c2.b));
	}

}
