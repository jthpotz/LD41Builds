﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy  {

	Vector2 position;

	bool active = false;

	Constants.EnemyTypes type;

	int direction = -1;

	public Vector2 Position {
		get {
			return position;
		}
	}

	public bool Active {
		get {
			return active;
		}
	}

	public Constants.EnemyTypes Type {
		get {
			return type;
		}
	}

	public int Direction {
		get {
			return direction;
		}
	}

	public Enemy (Constants.EnemyTypes t, Vector2 pos){
		type = t;
		position = pos;
	}

	public void Activate (){
		active = true;
	}

	public void Deactivate (){
		active = false;
	}

	public void SwitchDirections(){
		Debug.Log ("Swap");
		if(direction < 0){
			direction = 1;
			return;
		}
		direction = -1;
	}

	public void MoveRight (){
		position.x += 1;
	}

	public void MoveLeft (){
		position.x -= 1;
	}

	public void MoveUp(){
		position.y += 1;
	}

	public void MoveDown(){
		position.y -= 1;
	}
}
