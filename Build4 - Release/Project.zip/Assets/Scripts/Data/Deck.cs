﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Deck {

	List<Card> shuffled = new List<Card> ();
	List<Card> discard = new List<Card> ();

	public Card DrawCard (){

		if(shuffled.Count == 0){
			Shuffle ();
		}

		Card temp = shuffled [0];
		shuffled.Remove (shuffled[0]);
		return temp;
	}

	private void Shuffle (){
		shuffled = discard.OrderBy (card => Random.Range (0, discard.Count)).ToList ();
		discard = new List<Card> ();
//		Debug.Log (shuffled.Count);
//		Debug.Log (discard.Count);
	}

	public void Discard (Card c) {

		discard.Add (c);

	}

	public void AddCardToDeck(Card c){
		shuffled.Insert (Random.Range (0, shuffled.Count), c);
	}

}
