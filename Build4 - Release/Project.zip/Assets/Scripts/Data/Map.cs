﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TerrainTypes = Constants.TerrainTypes;

public class Map {

	Vector2 bottomLeftVisible;
	Vector2 topRightVisible;

	TileSpace[,] entireMap;

	public Vector2 BottomLeftVisible {
		get {
			return bottomLeftVisible;
		}
	}

	public Vector2 TopRightVisible {
		get {
			return topRightVisible;
		}
	}

	public TileSpace[,] EntireMap {
		get {
			return entireMap;
		}
	}

	public Map (TileSpace[,] em){
		entireMap = em;
		bottomLeftVisible = new Vector2 (-3, Constants.startingMapHeight);
		topRightVisible = new Vector2 (8, Constants.startingMapHeight + 4);
	}

	public void ShiftVisibleUp(){
//		if(topRightVisible.y + 1 >= entireMap.GetUpperBound (1)){
//			Debug.LogWarning ("Tried to go over map height!");
//			return;
//		}
		bottomLeftVisible.y = bottomLeftVisible.y + 1;
		topRightVisible.y = topRightVisible.y + 1;
	}

	public void ShiftVisibleDown(){
//		if (bottomLeftVisible.y - 1 < 0){
//			Debug.LogWarning ("Tried to go below map bottom!");
//			return;
//		}
		bottomLeftVisible.y = bottomLeftVisible.y - 1;
		topRightVisible.y = topRightVisible.y - 1;
	}

	public void ShiftVisibleRight(){
		if (topRightVisible.x + 1 >= entireMap.GetUpperBound (0)){
			Debug.LogWarning ("Tried to go past end of map!");
			return;
		}
		bottomLeftVisible.x = bottomLeftVisible.x + 1;
		topRightVisible.x = topRightVisible.x + 1;
	}

	public bool Passable(Vector2 loc){
		return entireMap [(int)loc.x, (int)loc.y].TerrainType == TerrainTypes.Sky;
	}

}
