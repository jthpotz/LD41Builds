﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TerrainTypes = Constants.TerrainTypes;

public class TileSpace  {

	TerrainTypes terrainType;

	public TerrainTypes TerrainType {
		get {
			return terrainType;
		}
	}

	public TileSpace (TerrainTypes t) {
		terrainType = t;
//		Debug.Log (terrainType); 
	}

	public override string ToString () {
		return string.Format ("[TileSpace: TerrainType={0}]", TerrainType);
	}

}
