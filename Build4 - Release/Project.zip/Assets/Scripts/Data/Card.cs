﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;

public abstract class Card  {

	Action<PlayerController> effect;

	Constants.CardNames name;

	Constants.CardTypes type;

	public Action<PlayerController> Effect {
		get {
			return effect;
		}
	}

	public Constants.CardNames Name {
		get {
			return name;
		}
	}

	public Constants.CardTypes Type {
		get {
			return type;
		}
	}

	public class Right : Card {
		public Right(){
			effect = RightAction;
			name = Constants.CardNames.Right;
			type = Constants.CardTypes.Movement;
		}

		public void RightAction(PlayerController pc){
//			Debug.Log ("Right");
			List<Transform> trs = pc.PM.gameObject.GetComponentsInChildren<Transform> ().ToList ();
			foreach (Transform tr in trs){
				if(tr.tag == "StrikeAnim"){
					tr.gameObject.SetActive (false);
//					Debug.Log ("Found"); 
				}
			}
			if(pc.OC.CheckGoal (new Vector2(pc.Player.Position.x+1, pc.Player.Position.y))){
				pc.SC.NextLevelScreen ();
			}
			pc.SC.MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/PlayerMove");
			pc.SC.MainAudioSource.Play ();
			if(pc.MC.Passable (new Vector2(pc.Player.Position.x+1, pc.Player.Position.y)) && !pc.EMC.CollideWithEnemy (new Vector2(pc.Player.Position.x+1, pc.Player.Position.y))){
				pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.moveHash);
				pc.EC.AddAnimatingAction (() => {
					pc.PM.transform.Translate (new Vector2 (Time.deltaTime*Constants.speed, 0));
					pc.EC.Amount += Time.deltaTime*Constants.speed;
					if (pc.EC.Amount >= 2){
						pc.EC.ClearAnimation ();
						pc.PM.transform.position = new Vector2 (Mathf.Round (pc.PM.transform.position.x), Mathf.Round (pc.PM.transform.position.y) - 0.0625f);
						pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
						pc.EC.CheckFalling (true);
					}
				});
				pc.Player.MoveRight ();
				pc.MC.Map.ShiftVisibleRight ();
			}
			else{
				pc.EC.GameOver ();
			}
		}

	}

	public class Jump : Card {
		public Jump(){
			effect = JumpAction;
			name = Constants.CardNames.Jump;
			type = Constants.CardTypes.Movement;
		}

		public void JumpAction(PlayerController pc){
//			Debug.Log ("Jump");
			if(pc.OC.CheckGoal (new Vector2(pc.Player.Position.x, pc.Player.Position.y-1))){
				pc.SC.NextLevelScreen ();
			}
			pc.SC.MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/Boost");
			pc.SC.MainAudioSource.Play ();
			if(pc.MC.Passable (new Vector2(pc.Player.Position.x, pc.Player.Position.y+1)) && !pc.MC.Passable (new Vector2(pc.Player.Position.x, pc.Player.Position.y-1)) && !pc.EMC.CollideWithEnemy (new Vector2(pc.Player.Position.x, pc.Player.Position.y+1))){
				pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.jumpHash);
				pc.EC.AddAnimatingAction (() => {
					pc.PM.transform.Translate (new Vector2 (0, Time.deltaTime*Constants.speed));
					pc.EC.Amount += Time.deltaTime*Constants.speed;
					if (pc.EC.Amount >= 2){
						pc.EC.ClearAnimation ();
						pc.PM.transform.position = new Vector2 (Mathf.Round (pc.PM.transform.position.x), Mathf.Round (pc.PM.transform.position.y) - 0.0625f);
						pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
					}
				});
				pc.Player.MoveUp ();
				pc.MC.Map.ShiftVisibleUp ();
				pc.Player.ActivateGlide ();
			}
		}

	}

	public class Dash : Card {
		public Dash(){
			effect = DashAction;
			name = Constants.CardNames.Dash;
			type = Constants.CardTypes.Movement;
		}

		public void DashAction(PlayerController pc){
//			Debug.Log ("Dash");
			if(pc.OC.CheckGoal (new Vector2(pc.Player.Position.x+1, pc.Player.Position.y))){
				pc.SC.NextLevelScreen ();
			}
			pc.SC.MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/Boost");
			pc.SC.MainAudioSource.Play ();
			if(pc.MC.Passable (new Vector2(pc.Player.Position.x+1, pc.Player.Position.y)) && !pc.EMC.CollideWithEnemy (new Vector2(pc.Player.Position.x+1, pc.Player.Position.y))){
				pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.dashHash);
				pc.EC.AddAnimatingAction (() => {
					pc.PM.transform.Translate (new Vector2 (Time.deltaTime*Constants.speed, 0));
					pc.EC.Amount += Time.deltaTime*Constants.speed;
					if (pc.EC.Amount >= 2){
						pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
						pc.PM.transform.position = new Vector2 (Mathf.Round (pc.PM.transform.position.x), Mathf.Round (pc.PM.transform.position.y) - 0.0625f);
						pc.EC.ClearAnimation ();
					}
				});
				pc.Player.MoveRight ();
				pc.MC.Map.ShiftVisibleRight ();
			}
			else{
				pc.EC.GameOver ();
			}
		}

	}

	public class Halt : Card {
		public Halt(){
			effect = HaltAction;
			name = Constants.CardNames.Halt;
			type = Constants.CardTypes.Movement;
		}

		public void HaltAction(PlayerController pc){
//			Debug.Log ("Halt");
			pc.EC.CheckFalling (true);
		}

	}

	public class Strike : Card {
		public Strike(){
			effect = StrikeAction;
			name = Constants.CardNames.Strike;
			type = Constants.CardTypes.Attack;
		}

		public void StrikeAction(PlayerController pc){
//			Debug.Log ("Beta");
			pc.SC.MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/Slash");
			pc.SC.MainAudioSource.Play ();
			pc.EC.AddAnimatingAction (() => {
				pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.hackHash);
				pc.EC.Amount += Time.deltaTime*Constants.speed;
				if (pc.EC.Amount >= 2){
					List<Transform> trs = pc.PM.gameObject.GetComponentsInChildren<Transform> ().ToList ();
					foreach (Transform tr in trs){
						if(tr.tag == "StrikeAnim"){
							tr.gameObject.SetActive (false);
						}
					}
					pc.PM.gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
					pc.EC.ClearAnimation ();
				}
			});
			if(pc.EMC.CollideWithEnemy (new Vector2(pc.Player.Position.x+1, pc.Player.Position.y))){
//				Debug.Log ("Attack!");
				EnemyManager em = pc.EMC.EnemyAt (new Vector2 (pc.Player.Position.x + 1, pc.Player.Position.y));
				em.Die ();
				pc.EMC.RemoveEnemy (em.gameObject);
			}
		}
	}
}

