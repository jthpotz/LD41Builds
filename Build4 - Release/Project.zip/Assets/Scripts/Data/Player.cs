﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player {

	Vector2 position;

	bool stopped;

	bool gliding;
	int glideRemaining = Constants.playerGlideAmount;

	public Vector2 Position {
		get {
			return position;
		}
	}

	public bool Stopped {
		get {
			return stopped;
		}
	}

	public bool Gliding {
		get {
			return gliding;
		}
	}

	public int GlideRemaining {
		get {
			return glideRemaining;
		}
	}

	public Player (){
		position = new Vector2 (1, Constants.startingPlayerHeight);
	}

	public void MoveUp(){
		position.y += 1;
	}

	public void MoveDown(){
		position.y -= 1;
	}

	public void MoveRight(){
		position.x += 1;
	}

	public void ToggleStopped(){
		if(stopped){
			stopped = false;
			return;
		}
		stopped = true;
	}

	public void ActivateGlide (){
		glideRemaining = Constants.playerGlideAmount;
		gliding = true;
	}

	public void HaltGlide(){
		gliding = false;
	}

	public void UseGlide(){
		glideRemaining--;	
	}

}
