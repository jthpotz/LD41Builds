﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Hand {

	Card[] currentHand = new Card [Constants.handSize+1];
	Action<Card> updateVisuals;

	public Card[] CurrentHand {
		get {
			return currentHand;
		}
	}

	public Hand(Deck deck) {
		currentHand [0] = new Card.Right ();
		for(int i = 1; i < currentHand.Length; i++){
			currentHand [i] = deck.DrawCard ();
		}
	}

	public void UseCardAt (int index, Deck deck){
//		currentHand [index].Effect (GameObject.FindGameObjectWithTag ("Player").GetComponent<PlayerController> ());
//		Debug.Log ("Hand: " + currentHand[index].Name);
		if(index != 0){
			deck.Discard (currentHand[index]);	
			currentHand [index] = null;
			ShiftDown (index);
			currentHand [currentHand.Length-1] = deck.DrawCard ();
		}
	}

	private void ShiftDown (int index){
		for (int i = index; i < currentHand.Length-1; i++){
			currentHand [i] = currentHand [i + 1];
			currentHand [i + 1] = null;
		}
	}

}
