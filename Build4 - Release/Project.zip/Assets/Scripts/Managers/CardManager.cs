﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardManager : MonoBehaviour {

	Ray ray;
	RaycastHit2D hit;

	bool over = false;

	bool clickStartedOver = false;

	CardController cc;
	EventController ec;

	// Use this for initialization
	void Start () {
		cc = GameObject.FindGameObjectWithTag ("CardController").GetComponent<CardController> ();
		ec = GameObject.FindGameObjectWithTag ("EventController").GetComponent<EventController> ();
	}
	
	// Update is called once per frame
	void Update () {

		ray = Camera.main.ScreenPointToRay ((Input.mousePosition));
//		ray.origin = Camera.main.transform.position;

		hit = Physics2D.Raycast (ray.origin, ray.direction*10000, Mathf.Infinity);
		Debug.DrawRay (ray.origin, ray.direction*1000, Color.red, Mathf.Infinity);
		if(hit.collider != null && hit.collider.transform == gameObject.transform){
//			Debug.Log (hit.transform.name);
			over = true;
		}
		else {
//			Debug.Log ("Miss");
			over = false;
		}


		if(over && !cc.Shifting && !ec.DoTurn && !ec.Animating) {
			
			gameObject.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite> ("Art/Cards/" + gameObject.tag + "Highlighted");
			if(Input.GetMouseButtonDown (0)){
				clickStartedOver = true;
			}
		}
		else {
			gameObject.GetComponent<SpriteRenderer> ().sprite = Resources.Load<Sprite> ("Art/Cards/" + gameObject.tag);
		}

		if(Input.GetMouseButtonUp (0)){
			if(clickStartedOver && over && !cc.Shifting && !ec.DoTurn && !ec.Animating){
				cc.UseCard (gameObject);
				if(gameObject.tag != "Right"){
					GameObject.Destroy (gameObject);
				}
			}
			clickStartedOver = false;
		}

	}
}
