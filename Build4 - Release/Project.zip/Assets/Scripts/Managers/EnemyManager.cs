﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour {

	Enemy enemy;

	EventController ec;
	MapController mc;
	PlayerController pc;
	EnemyController emc;

	Animator animator;

	int bounce = 0;
	bool down = false;

	public Enemy Enemy {
		get {
			return enemy;
		}
	}

	// Use this for initialization
	void Start () {
		ec = GameObject.FindGameObjectWithTag ("EventController").GetComponent<EventController> ();
		mc = GameObject.FindGameObjectWithTag ("MapController").GetComponent<MapController> ();
		pc = GameObject.FindGameObjectWithTag ("PlayerController").GetComponent<PlayerController> ();
		emc = GameObject.FindGameObjectWithTag ("EnemyController").GetComponent<EnemyController> ();
		animator = GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (enemy == null) {
			Debug.LogWarning ("Enemy not initialized.");
		}
		if (animator.GetBool ("Done")) {
			emc.RemoveEnemy (gameObject);
			GameObject.Destroy (gameObject);
		}
	}

	public bool CheckForActive () {
		if (mc.InsideVisibleArea (enemy.Position)) {
			enemy.Activate ();
//			Debug.Log ("Enemy Active!"); 
			return true;
		}
		enemy.Deactivate ();
		return false;
	}

	public void InitializeEnemy (Enemy e) {
		enemy = e;
	}

	public void DoAction () {
//		Debug.Log ("Queued Enemy Action"); 
		switch (enemy.Type) {
			case Constants.EnemyTypes.Slime:
				ec.QueueAction (() => {
//					Debug.Log ("Enemy Action: " + enemy.Position);
					if (enemy.Direction < 0) {
//						Debug.Log ("Point1");
						if (new Vector2 (enemy.Position.x - 1, enemy.Position.y) == pc.Player.Position) {
							ec.GameOver ();
						}
						if (!mc.Passable (new Vector2 (enemy.Position.x - 1, enemy.Position.y))) {
//							Debug.Log ("Point2");
							enemy.SwitchDirections ();
						}
					} else {
//						Debug.Log ("Point3");
						if (new Vector2 (enemy.Position.x + 1, enemy.Position.y) == pc.Player.Position) {
							ec.GameOver ();
						}
						if (!mc.Passable (new Vector2 (enemy.Position.x + 1, enemy.Position.y))) {
//							Debug.Log ("Point4");
							enemy.SwitchDirections ();
						}
					}
					try {
						gameObject.GetComponent<Animator> ().SetTrigger (Constants.moveHash);
					} catch {
					}
							pc.SC.MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/SlimeMove");
							pc.SC.MainAudioSource.Play ();
					ec.AddAnimatingAction (() => {
						try {
							//						Debug.Log ("Enemy Animation");
							if (enemy.Direction < 0) {
//								Debug.Log (new Vector2 (-1*Time.deltaTime*Constants.speed, 0));
//								Debug.Log (transform);
								transform.Translate (new Vector2 (-1 * Time.deltaTime * Constants.speed, 0));
							} else {
								transform.Translate (new Vector2 (Time.deltaTime * Constants.speed, 0));
							}

							ec.Amount += Time.deltaTime * Constants.speed;
							if (ec.Amount >= 2) {
								ec.ClearAnimation ();
								gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
								transform.position = new Vector2 (Mathf.Round (transform.position.x), Mathf.Round (transform.position.y) - 0.0625f);
								ec.CheckFalling (false, this);
							}
						} catch {
							ec.ClearAnimation ();
							//gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
						}
					});
					if (enemy.Direction < 0) {
						enemy.MoveLeft ();
					} else {
						enemy.MoveRight ();
					}
				});
				break;
			case Constants.EnemyTypes.Bouncy:
				ec.QueueAction (() => {
					try {
						Vector2? newPos = null;
						SpriteRenderer sr = transform.GetComponent<SpriteRenderer> ();
						Sprite sprite = null;
						switch (bounce) {
							case 0:
								down = false;
								bounce++;
								newPos = new Vector2 (enemy.Position.x, enemy.Position.y + 1);
								enemy.MoveUp ();
								sprite = Resources.Load<Sprite> ("Art/Enemies/Bouncy/Bouncy1");
								break;
							case 1:
								if (down) {
									bounce--;
									newPos = new Vector2 (enemy.Position.x, enemy.Position.y - 1);
									enemy.MoveDown ();
									sprite = Resources.Load<Sprite> ("Art/Enemies/Bouncy/Bouncy2");
								} else {
									bounce++;
									newPos = new Vector2 (enemy.Position.x, enemy.Position.y + 1);
									enemy.MoveUp ();
									sprite = Resources.Load<Sprite> ("Art/Enemies/Bouncy/Bouncy0");
								}
								break;
							case 2:
								down = true;
								bounce--;
								newPos = new Vector2 (enemy.Position.x, enemy.Position.y - 1);
								enemy.MoveDown ();
								sprite = Resources.Load<Sprite> ("Art/Enemies/Bouncy/Bouncy0");
								break;
						}
//						Debug.Log(sprite);
//						Debug.Log (sr);
						transform.GetComponent<SpriteRenderer> ().sprite = sprite;
						if (newPos.Value == pc.Player.Position) {
							pc.EC.GameOver ();
						}
					} catch {
					}
					ec.AddAnimatingAction (() => {
						try {
//													Debug.Log ("Enemy Animation");
//							Debug.Log (new Vector2 (0, Time.deltaTime * Constants.speed));
							if (down) {
								//								Debug.Log (new Vector2 (-1*Time.deltaTime*Constants.speed, 0));
								//								Debug.Log (transform);
								transform.Translate (new Vector2 (0, -1 * Time.deltaTime * Constants.speed));
							} else {
//								Debug.Log(transform.position);
								transform.Translate (new Vector2 (0, Time.deltaTime * Constants.speed));
//								Debug.Log(transform.position);
//								Debug.Log("Yay!");
							}

							ec.Amount += Time.deltaTime * Constants.speed;
							if (ec.Amount >= 2) {
								ec.ClearAnimation ();
//								gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
								transform.position = new Vector2 (Mathf.Round (transform.position.x), Mathf.Round (transform.position.y) - 0.0625f);
//								ec.CheckFalling (false, this);
							}
						} catch {
							ec.ClearAnimation ();
							//gameObject.GetComponent<Animator> ().SetTrigger (Constants.idleHash);
						}
					});

				});
				break;
				
		}
	}

	public void Die () {
		animator.SetTrigger (Constants.deadHash);
//		pc.SC.MainAudioSource.clip = Resources.Load<AudioClip> ("Sounds/Bop");
//		pc.SC.MainAudioSource.Play ();
	}

}
