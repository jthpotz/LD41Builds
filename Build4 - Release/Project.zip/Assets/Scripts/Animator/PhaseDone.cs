﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhaseDone : StateMachineBehaviour {

	public override void OnStateExit (Animator animator, AnimatorStateInfo stateInfo, int layerIndex){
		if(stateInfo.IsName ("Dead")){
			animator.SetBool ("Done", true);
		}
	}

}
